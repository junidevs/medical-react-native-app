import { type RemoteScreenModule } from "@medconnect/mf-contracts";
declare const moduleExport: RemoteScreenModule;
export default moduleExport;
